const express = require("express")
const mongoose = require("mongoose")
const port = process.env.Port || 5000;
const hbs = require("hbs");
const app = express();
require("./db/conn")
const path = require("path");
const Register = require('./models/registers');
const { urlencoded } = require("express");
// const MensRanking =require("./models/mens")
// const router =require("./router/mensrouter")
const static_path = path.join(__dirname, "../public")
const template_path = path.join(__dirname, "../templates/views")
const partial_path = path.join(__dirname, "../templates/partials")
app.use(express.static(static_path))
app.set("view engine", "hbs");
app.set("views", template_path)
hbs.registerPartials(partial_path)
app.use(express.json())
app.use(urlencoded({ extended: false }))
app.get("/", (req, res) => {
    res.render("index")
})
app.get("/register", (req, res) => {
    res.render("register")
})

app.post("/register", async (req, res) => {
    try {
        console.log(req.body.name)
        res.send(req.body.name)
    } catch (e) {
        res.send(e)
    }
})



app.use(express.json())
// app.use(router)






app.listen(port, () => {
    console.log(`connectio is set at ${port}`);
})