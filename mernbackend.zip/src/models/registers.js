const mongoose =require("mongoose");

const employeeSchema =new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
        },
        lastname: {
            type: String,
            required: true,
        },
        email: {
            type: String,
            required: true,
            unique:true
        },
        age: {
            type: Number,
            required: true,
        },
        gender: {
            type: String,
            required: true,
            
        },
        phoneno: {
            type: Number,
            required: true,
            
        },
        password: {
            type: Number,
            required: true,
            
        },
        cnfirmpassword: {
            type: Number,
            required: true,
            
        }
        
    }
)
const Register =new mongoose.model('Register',employeeSchema)

module.exports =Register;